/* Name of libgcc_s library provided by gcc, m68k version.  */
#define LIBGCC_S_SO "libgcc_s.so.2"
