#define FUNC sincosl
#define float_type long double
#include <s_sincos.c>
