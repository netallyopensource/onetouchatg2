#define FUNC sincosf
#define float_type float
#include <s_sincos.c>
