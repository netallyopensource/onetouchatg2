#define	FUNC	sinf
#include <s_atanf.c>
