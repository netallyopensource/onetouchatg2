#define FUNC __ieee754_expl
#include <e_acosl.c>
