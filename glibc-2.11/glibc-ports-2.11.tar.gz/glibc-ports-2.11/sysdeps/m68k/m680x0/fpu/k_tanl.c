#define FUNC tanl
#define float_type long double
#include <k_tan.c>
