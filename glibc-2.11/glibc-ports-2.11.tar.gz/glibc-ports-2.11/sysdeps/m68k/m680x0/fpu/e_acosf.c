#ifndef	FUNC
#define	FUNC	__ieee754_acosf
#endif
#define float_type float
#include <e_acos.c>
