#define	FUNC	__ieee754_log
#include <e_acos.c>
