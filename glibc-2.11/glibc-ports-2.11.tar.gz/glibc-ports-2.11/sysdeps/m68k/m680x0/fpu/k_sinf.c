#define FUNC sinf
#define float_type float
#include <k_sin.c>
