#define	FUNC	expm1f
#include <s_atanf.c>
