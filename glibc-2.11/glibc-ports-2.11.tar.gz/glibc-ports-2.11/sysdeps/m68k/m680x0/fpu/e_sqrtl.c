#define FUNC __ieee754_sqrtl
#include <e_acosl.c>
