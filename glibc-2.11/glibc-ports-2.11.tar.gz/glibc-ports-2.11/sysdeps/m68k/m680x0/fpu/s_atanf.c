#ifndef FUNC
#define FUNC atanf
#endif
#define float_type float
#include <s_atan.c>
