#define	FUNC	sin
#include <s_atan.c>
