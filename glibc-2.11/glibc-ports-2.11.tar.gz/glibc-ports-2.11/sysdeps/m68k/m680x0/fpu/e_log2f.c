#define FUNC    __ieee754_log2f
#include <e_acosf.c>
