#define	FUNC	cosf
#include <s_atanf.c>
