#define	FUNC	__ieee754_expf
#include <e_acosf.c>
