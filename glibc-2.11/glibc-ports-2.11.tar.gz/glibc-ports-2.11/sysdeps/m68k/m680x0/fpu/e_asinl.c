#define FUNC __ieee754_asinl
#include <e_acosl.c>
