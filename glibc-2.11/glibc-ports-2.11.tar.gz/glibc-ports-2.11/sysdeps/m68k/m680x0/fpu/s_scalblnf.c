/* Nothing to do.  This function is the same as scalbnf.  So we define an
   alias.  */
