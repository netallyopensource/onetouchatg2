#include <sysdeps/ia64/backtrace.c>
