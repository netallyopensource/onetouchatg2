struct link_map_machine
  {
    Elf32_Addr plt; /* Address of .plt */
  };
