#ifndef FUNC
#define FUNC __ieee754_acosl
#endif
#define float_type long double
#include <e_acos.c>
