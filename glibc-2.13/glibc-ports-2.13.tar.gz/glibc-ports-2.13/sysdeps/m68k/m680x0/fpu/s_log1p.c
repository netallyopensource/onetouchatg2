#define	FUNC	log1p
#include <s_atan.c>
