#define FUNC __ieee754_exp10f
#include <e_acosf.c>
