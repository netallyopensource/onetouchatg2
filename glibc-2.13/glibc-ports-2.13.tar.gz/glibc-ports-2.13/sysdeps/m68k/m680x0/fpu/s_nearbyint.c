#define	FUNC nearbyint
#include <s_atan.c>
