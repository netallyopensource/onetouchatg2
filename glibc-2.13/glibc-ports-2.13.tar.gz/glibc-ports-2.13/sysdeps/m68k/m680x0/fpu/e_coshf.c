#define	FUNC	__ieee754_coshf
#include <e_acosf.c>
