#define	FUNC	ceil
#include <s_atan.c>
