#define	FUNC	__ieee754_sqrt
#include <e_acos.c>
