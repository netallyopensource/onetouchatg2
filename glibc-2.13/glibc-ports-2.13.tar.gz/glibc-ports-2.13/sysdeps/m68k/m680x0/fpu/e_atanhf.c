#define	FUNC	__ieee754_atanhf
#include <e_acosf.c>
