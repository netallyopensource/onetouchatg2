#define	FUNC	ceilf
#include <s_atanf.c>
