#define FUNC cosf
#define float_type float
#include <k_cos.c>
