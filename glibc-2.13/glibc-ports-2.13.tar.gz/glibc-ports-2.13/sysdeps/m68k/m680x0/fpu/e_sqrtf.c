#define	FUNC	__ieee754_sqrtf
#include <e_acosf.c>
