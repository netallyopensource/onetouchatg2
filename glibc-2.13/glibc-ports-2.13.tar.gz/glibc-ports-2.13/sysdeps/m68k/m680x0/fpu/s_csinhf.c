#define SUFF f
#define float_type float
#include <s_csinh.c>
