#define FUNC rintl
#include <s_atanl.c>
