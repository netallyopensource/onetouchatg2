#define FUNC __ieee754_sinhl
#include <e_acosl.c>
