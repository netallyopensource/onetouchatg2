#ifndef FUNC
#define FUNC __ieee754_fmodf
#endif
#define float_type float
#include <e_fmod.c>
