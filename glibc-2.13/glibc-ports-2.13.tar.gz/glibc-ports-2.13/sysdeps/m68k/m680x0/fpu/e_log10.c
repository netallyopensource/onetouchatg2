#define	FUNC	__ieee754_log10
#include <e_acos.c>
