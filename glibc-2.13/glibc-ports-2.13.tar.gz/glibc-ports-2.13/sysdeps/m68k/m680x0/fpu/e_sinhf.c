#define	FUNC	__ieee754_sinhf
#include <e_acosf.c>
