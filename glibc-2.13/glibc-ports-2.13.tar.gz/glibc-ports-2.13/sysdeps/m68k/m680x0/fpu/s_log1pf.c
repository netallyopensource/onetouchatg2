#define	FUNC	log1pf
#include <s_atanf.c>
