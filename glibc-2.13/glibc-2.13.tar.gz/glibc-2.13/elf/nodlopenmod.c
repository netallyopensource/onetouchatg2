int a = 42;
