/* Test STT_GNU_IFUNC symbols with -fPIC and -static.  */

#include "ifuncmain1.c"
