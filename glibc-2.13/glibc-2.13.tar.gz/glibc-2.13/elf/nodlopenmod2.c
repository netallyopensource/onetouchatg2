extern int a;

extern int foo (void);

int
foo (void)
{
  return a;
}
