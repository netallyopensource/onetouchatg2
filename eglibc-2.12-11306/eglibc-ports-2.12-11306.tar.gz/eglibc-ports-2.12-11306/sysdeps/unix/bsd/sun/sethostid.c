#include <misc/sethostid.c>
