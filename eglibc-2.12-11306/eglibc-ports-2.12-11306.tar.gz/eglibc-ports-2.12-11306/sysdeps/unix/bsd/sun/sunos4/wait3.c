#include <sysdeps/unix/bsd/bsd4.4/wait3.c>
