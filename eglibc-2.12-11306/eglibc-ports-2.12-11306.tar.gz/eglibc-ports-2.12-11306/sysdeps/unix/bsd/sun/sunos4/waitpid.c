#include <sysdeps/unix/bsd/bsd4.4/waitpid.c>
