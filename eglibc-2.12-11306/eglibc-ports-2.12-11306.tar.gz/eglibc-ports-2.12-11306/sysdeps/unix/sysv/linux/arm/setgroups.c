/* We also have to rewrite the kernel gid_t to the user land type.  */
#include <sysdeps/unix/sysv/linux/i386/setgroups.c>
