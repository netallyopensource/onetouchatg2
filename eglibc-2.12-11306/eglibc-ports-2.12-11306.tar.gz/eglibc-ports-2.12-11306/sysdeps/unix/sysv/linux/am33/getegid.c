#include <sysdeps/unix/sysv/linux/i386/getegid.c>
