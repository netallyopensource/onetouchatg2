#include <sysdeps/unix/sysv/linux/i386/lockf64.c>
