#include <sysdeps/unix/sysv/linux/i386/setregid.c>
