#ifndef __ASSEMBLY__
extern void __start (void);
#endif

#define ENTRY_POINT __start
