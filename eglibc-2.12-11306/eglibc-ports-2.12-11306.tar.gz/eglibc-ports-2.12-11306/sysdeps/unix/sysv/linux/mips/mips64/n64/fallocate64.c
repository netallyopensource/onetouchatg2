/* fallocate64 is in fallocate.c */
