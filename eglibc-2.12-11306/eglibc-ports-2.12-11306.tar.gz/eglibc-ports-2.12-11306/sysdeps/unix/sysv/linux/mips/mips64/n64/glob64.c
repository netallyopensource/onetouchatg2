/* glob64 is in glob.c */
