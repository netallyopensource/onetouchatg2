#include <sysdeps/unix/sysv/linux/ia64/getpagesize.c>
