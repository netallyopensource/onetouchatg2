#include <sysdeps/unix/sysv/linux/wordsize-64/posix_fallocate.c>
