#include <sysdeps/unix/sysv/linux/hppa/umount.c>
