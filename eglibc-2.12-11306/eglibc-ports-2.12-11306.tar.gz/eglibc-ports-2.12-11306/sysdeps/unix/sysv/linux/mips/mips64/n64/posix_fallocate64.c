/* posix_fallocate64 is in posix_fallocate.c */
