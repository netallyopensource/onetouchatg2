/* Empty since the pwritev syscall is equivalent.  */
