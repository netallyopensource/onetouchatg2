/* posix_fadvise64 is in posix_fadvise.c */
