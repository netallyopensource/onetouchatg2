/* Empty since the preadv syscall is equivalent.  */
