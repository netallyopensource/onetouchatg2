/* lseek() is 64-bit capable already.  */
