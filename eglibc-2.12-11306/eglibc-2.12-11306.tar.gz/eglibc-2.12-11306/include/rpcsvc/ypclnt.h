#ifndef __RPCSVC_YPCLNT_H__
#include <nis/rpcsvc/ypclnt.h>

libnsl_hidden_proto (ypbinderr_string)
libnsl_hidden_proto (yp_bind)
libnsl_hidden_proto (yp_get_default_domain)
libnsl_hidden_proto (ypprot_err)
libnsl_hidden_proto (yp_master)

#endif
