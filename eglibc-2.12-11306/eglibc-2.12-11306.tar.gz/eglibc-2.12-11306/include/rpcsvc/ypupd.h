#ifndef __RPCSVC_YPUPD_H__
#include <nis/rpcsvc/ypupd.h>

libnsl_hidden_proto (xdr_yp_buf)
libnsl_hidden_proto (xdr_ypdelete_args)
libnsl_hidden_proto (xdr_ypupdate_args)

#endif
