#include_next <bits/dlfcn.h>

extern void _dl_mcount_wrapper_check (void *__selfpc);
libc_hidden_proto (_dl_mcount_wrapper_check)
