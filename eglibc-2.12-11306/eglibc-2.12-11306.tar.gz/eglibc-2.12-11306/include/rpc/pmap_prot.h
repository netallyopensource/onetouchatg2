#include <sunrpc/rpc/pmap_prot.h>


extern bool_t xdr_pmap_internal (XDR *__xdrs, struct pmap *__regs)
  attribute_hidden;
extern bool_t xdr_pmaplist_internal (XDR *__xdrs, struct pmaplist **__rp)
  attribute_hidden;
